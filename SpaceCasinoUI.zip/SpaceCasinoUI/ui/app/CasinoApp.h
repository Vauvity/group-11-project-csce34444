#ifndef CASINOAPP_H
#define CASINOAPP_H

#include <SFML/Graphics.hpp>
#include "AppState.h"
#include "../screens/welcome/MainMenu.h"
#include "../screens/hub/GameSelect.h"
#include "../screens/blackjack/BlackjackUI.h"
#include "../screens/slots/SlotsUI.h"

class CasinoApp
{
public:
    CasinoApp();
    void run();

private:
    void processEvents();
    void render();
    void syncGameSelectBankroll();
    void syncBlackjackBankroll();
    void syncSlotsBankroll();
    void resetSessionIfNeeded();

    sf::RenderWindow window;
    sf::Font font;

    MainMenu mainMenu;
    GameSelect gameSelect;
    BlackjackUI blackjackUI;
    SlotsUI slotsUI;

    AppState currentState;
    double sharedBankroll;
    bool bankrollInitialized;
};

#endif